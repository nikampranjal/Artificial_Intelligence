import streamlit as st
import pandas as pd
import folium
import matplotlib.pyplot as plt
from streamlit_folium import st_folium

import sys
import os

# Load dataset
df = pd.read_csv("data.csv")

sys.path.insert(0, os.path.abspath("."))

from route_optimizer import RouteOptimizer
from cargo_predictor import CargoPredictor

st.set_page_config(layout="wide")
st.title("✈ Airline Scheduling + Cargo Prediction AI")

optimizer = RouteOptimizer()
predictor = CargoPredictor()

airports = optimizer.airports

# Clean airport list
airport_codes = sorted(airports["City"].dropna().unique().tolist())

# -------------------------------
# AIRPORT SELECTION
# -------------------------------
source = st.selectbox("Select Source Airport", airport_codes)
destination = st.selectbox("Select Destination Airport", airport_codes)

distance = 0

# -------------------------------
# DISTANCE CALCULATION
# -------------------------------
if source != destination:

    result = optimizer.get_best_route(source, destination)

    if isinstance(result, str):
        st.error(result)
    else:
        distance = result["distance_km"]

        st.write("Source:", source)
        st.write("Destination:", destination)
        st.success(f"Distance between airports: {distance:.2f} km")

# -------------------------------
# ROUTE VISUALIZATION
# -------------------------------
if 'show_map' not in st.session_state:
    st.session_state.show_map = False

if st.button("Find Best Route"):
    st.session_state.show_map = True

if st.session_state.show_map:

    result = optimizer.get_best_route(source, destination)

    if isinstance(result, str):
        st.error(result)
    else:
        st.success(f"Optimal Route: {source} → {destination}")

        src_row = airports[airports["City"] == source].iloc[0]
        dst_row = airports[airports["City"] == destination].iloc[0]

        m = folium.Map(
            location=[src_row["Latitude"], src_row["Longitude"]],
            zoom_start=5
        )

        folium.Marker(
            [src_row["Latitude"], src_row["Longitude"]],
            popup=source
        ).add_to(m)

        folium.Marker(
            [dst_row["Latitude"], dst_row["Longitude"]],
            popup=destination
        ).add_to(m)

        folium.PolyLine(
            [
                [src_row["Latitude"], src_row["Longitude"]],
                [dst_row["Latitude"], dst_row["Longitude"]]
            ],
            color="blue"
        ).add_to(m)

        st_folium(m, width=700, height=500, key="flight_map")

# -------------------------------
# CARGO PREDICTION + PRICING
# -------------------------------
st.header("📦 Cargo Load Prediction & Pricing")

# Manual input instead of slider
cargo_weight = st.number_input(
    "Enter Cargo Weight (kg)",
    min_value=0,
    max_value=50000,
    value=2000,
    step=100
)

# Optional demand (for ML model)
demand = st.number_input(
    "Cargo Demand",
    min_value=10,
    max_value=500,
    value=100,
    step=10
)

# -------------------------------
# Cargo limit logic
# -------------------------------
def get_cargo_limit(distance):
    if distance < 1000:
        return 5000
    elif distance < 3000:
        return 8000
    else:
        return 12000

cargo_limit = get_cargo_limit(distance)

# -------------------------------
# Prediction + Cost Calculation
# -------------------------------
if st.button("Predict Cargo"):

    try:
        # ML Prediction (keep demand-based input)
        prediction = predictor.predict(distance, demand)

        # Base pricing
        base_cost = cargo_weight * 0.45

        # Extra charge if overloaded
        extra_charge = 0
        if cargo_weight > cargo_limit:
            extra_weight = cargo_weight - cargo_limit
            extra_charge = extra_weight * 0.75

        total_cost = base_cost + extra_charge

        # -------------------------------
        # OUTPUT
        # -------------------------------
        st.success(f"Predicted Cargo Capacity: {prediction:.2f} kg")

        st.info(f"Route Distance: {distance:.2f} km")
        st.info(f"Allowed Cargo Limit: {cargo_limit} kg")

        if cargo_weight > cargo_limit:
            st.warning(f"⚠ Excess Cargo: {cargo_weight - cargo_limit} kg")
            st.error(f"Extra Charges Applied: ₹{round(extra_charge, 2)}")

        st.success(f"💰 Total Transport Cost: ₹{round(total_cost, 2)}")

        # -------------------------------
        # GRAPH
        # -------------------------------
        fig, ax = plt.subplots()
        ax.scatter(distance, prediction, color="red")
        ax.set_xlabel("Distance (km)")
        ax.set_ylabel("Predicted Cargo")
        ax.set_title("Cargo Prediction Graph")

        st.pyplot(fig)

    except Exception as e:
        st.error(f"Prediction error: {e}")