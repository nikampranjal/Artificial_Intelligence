import pandas as pd
from math import radians, cos, sin, asin, sqrt

class RouteOptimizer:

    def __init__(self):
        dataset_path = "data.csv"   # Make sure this file exists
        self.airports = pd.read_csv(dataset_path)

    def calculate_distance(self, lat1, lon1, lat2, lon2):
        # Convert to radians
        lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

        dlon = lon2 - lon1
        dlat = lat2 - lat1

        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * asin(sqrt(a))

        return 6371 * c  # Distance in km

    def get_route(self, source_city, dest_city):
        try:
            src = self.airports[self.airports["City"] == source_city].iloc[0]
            dst = self.airports[self.airports["City"] == dest_city].iloc[0]

            distance = self.calculate_distance(
                src["Latitude"],
                src["Longitude"],
                dst["Latitude"],
                dst["Longitude"]
            )

            return {
                "source": source_city,
                "destination": dest_city,
                "distance_km": round(distance, 2)
            }

        except IndexError:
            return "Invalid city name. Please check dataset."

    # 🔥 FIX: Add this method to match your app.py
    def get_best_route(self, source_city, dest_city):
        return self.get_route(source_city, dest_city)