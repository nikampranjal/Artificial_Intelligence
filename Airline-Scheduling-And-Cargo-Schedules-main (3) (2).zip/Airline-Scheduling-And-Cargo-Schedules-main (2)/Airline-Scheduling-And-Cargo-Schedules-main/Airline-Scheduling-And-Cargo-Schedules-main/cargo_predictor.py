import numpy as np
import joblib


class CargoPredictor:

    def __init__(self):

        self.model = joblib.load("models/cargo_model.pkl")

    def predict(self, distance, demand):
        return self.model.predict([[distance, demand]])[0]