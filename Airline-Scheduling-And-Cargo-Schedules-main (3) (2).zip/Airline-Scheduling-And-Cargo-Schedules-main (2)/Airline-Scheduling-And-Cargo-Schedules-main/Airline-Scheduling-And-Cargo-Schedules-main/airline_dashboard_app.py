import streamlit as st
import pandas as pd
import numpy as np
import folium
from streamlit_folium import st_folium
import networkx as nx
from math import radians, sin, cos, sqrt, atan2
import os

# --------------------------------------------------
# PAGE CONFIG
# --------------------------------------------------

st.set_page_config(
    page_title="✈ Airline Scheduling & Cargo AI",
    layout="wide",
    page_icon="✈"
)

# --------------------------------------------------
# CUSTOM STYLING
# --------------------------------------------------

st.markdown("""
<style>
.main {
    background-color: #0f172a;
}

h1 {
    color: white;
    text-align: center;
}

.metric-card {
    background: linear-gradient(135deg,#1e293b,#334155);
    padding: 20px;
    border-radius: 12px;
    text-align: center;
    color: white;
    font-size: 20px;
}
</style>
""", unsafe_allow_html=True)

# --------------------------------------------------
# TITLE
# --------------------------------------------------

st.title("✈ Airline Scheduling & Cargo Prediction AI Dashboard")

# --------------------------------------------------
# LOAD DATASET
# --------------------------------------------------

DATA_PATH = os.path.join("data", "data.csv")

if not os.path.exists(DATA_PATH):
    st.error("Dataset not found: data.csv")
    st.stop()


# Load dataset

df = pd.read_csv(DATA_PATH)

# --------------------------------------------------
# DISTANCE FUNCTION
# --------------------------------------------------

def haversine(lat1, lon1, lat2, lon2):

    R = 6371

    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)

    a = sin(dlat/2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon/2)**2

    return 2 * R * atan2(sqrt(a), sqrt(1-a))


# --------------------------------------------------
# BUILD ROUTE GRAPH
# --------------------------------------------------

@st.cache_resource

def build_graph(data):

    G = nx.Graph()

    sample = data.head(300)

    for i in range(len(sample)):

        for j in range(i + 1, len(sample)):

            dist = haversine(
                sample.iloc[i]["Latitude"],
                sample.iloc[i]["Longitude"],
                sample.iloc[j]["Latitude"],
                sample.iloc[j]["Longitude"]
            )

            if dist < 1500:

                G.add_edge(
                    sample.iloc[i]["City"],
                    sample.iloc[j]["City"],
                    weight=dist
                )

    return G


route_graph = build_graph(df)


# --------------------------------------------------
# SIDEBAR CONTROLS
# --------------------------------------------------

st.sidebar.title("⚙ Route Controls")

source = st.sidebar.selectbox("Select Source City", df["City"].unique())

destination = st.sidebar.selectbox("Select Destination City", df["City"].unique())

cargo_weight = st.sidebar.slider("Cargo Weight (kg)", 100, 10000, 2000)

priority = st.sidebar.selectbox("Cargo Priority", ["Low", "Medium", "High"])


# --------------------------------------------------
# METRIC CARDS
# --------------------------------------------------

col1, col2, col3 = st.columns(3)

with col1:

    st.markdown(f"""
    <div class="metric-card">
    🌍 Total Airports<br>
    <b>{len(df)}</b>
    </div>
    """, unsafe_allow_html=True)


with col2:

    st.markdown(f"""
    <div class="metric-card">
    🏙 Cities Covered<br>
    <b>{df['City'].nunique()}</b>
    </div>
    """, unsafe_allow_html=True)


with col3:

    st.markdown(f"""
    <div class="metric-card">
    📦 Cargo Weight<br>
    <b>{cargo_weight} kg</b>
    </div>
    """, unsafe_allow_html=True)


st.divider()

# --------------------------------------------------
# SHORTEST ROUTE CALCULATION
# --------------------------------------------------

try:

    shortest_path = nx.shortest_path(
        route_graph,
        source,
        destination,
        weight="weight"
    )

except:

    shortest_path = [source, destination]


# --------------------------------------------------
# MAP VISUALIZATION
# --------------------------------------------------

st.subheader("🌍 AI Optimized Flight Route Map")

src_data = df[df["City"] == source].iloc[0]

dst_data = df[df["City"] == destination].iloc[0]

map_center = [
    (src_data["Latitude"] + dst_data["Latitude"]) / 2,
    (src_data["Longitude"] + dst_data["Longitude"]) / 2
]

route_map = folium.Map(location=map_center, zoom_start=5)


# Draw nodes

for city in shortest_path:

    row = df[df["City"] == city].iloc[0]

    folium.Marker(
        [row["Latitude"], row["Longitude"]],
        popup=city,
        icon=folium.Icon(color="blue")
    ).add_to(route_map)


# Draw optimized path

coordinates = []

for city in shortest_path:

    row = df[df["City"] == city].iloc[0]

    coordinates.append([
        row["Latitude"],
        row["Longitude"]
    ])


folium.PolyLine(
    coordinates,
    weight=5
).add_to(route_map)


st_folium(route_map, width=1200)


st.success(f"Optimized Route: {' ➝ '.join(shortest_path)}")


# --------------------------------------------------
# CARGO COST ESTIMATION
# --------------------------------------------------

priority_score = {
    "Low": 1,
    "Medium": 2,
    "High": 3
}[priority]

estimated_cost = cargo_weight * priority_score * 0.45

estimated_time = len(shortest_path) * 2


col4, col5 = st.columns(2)

with col4:

    st.success(f"Estimated Delivery Time: {estimated_time} hrs")


with col5:

    st.info(f"Estimated Transport Cost: ₹{round(estimated_cost,2)}")


st.divider()


# --------------------------------------------------
# DATASET PREVIEW
# --------------------------------------------------

st.subheader("📊 Airport Dataset Preview")

st.dataframe(df.head(50), use_container_width=True)


st.caption("Developed By Anushka Dale")




#streamlit run airline_dashboard_app.py