import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib
import os

# ✅ Better dataset
data = pd.DataFrame({
    "distance": [200, 500, 800, 1200, 1600, 2000, 3000, 5000, 8000, 10000],
    "demand":   [20, 50, 70, 100, 130, 160, 220, 300, 400, 450],
    "cargo_load": [15, 45, 60, 90, 120, 150, 210, 280, 350, 420]
})

X = data[["distance", "demand"]]
y = data["cargo_load"]

model = LinearRegression()
model.fit(X, y)

os.makedirs("models", exist_ok=True)
joblib.dump(model, "models/cargo_model.pkl")

print("Model trained successfully!")